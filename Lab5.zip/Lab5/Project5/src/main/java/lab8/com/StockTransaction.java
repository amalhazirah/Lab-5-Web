package lab8.com;

public class StockTransaction {
    private int shares;
    private double pricePerShare;
    private double commissionRate;
    private double amountPaid;
    private double commission;
    private double totalAmount;

    public StockTransaction(int shares, double pricePerShare, double commissionRate) {
        this.shares = shares;
        this.pricePerShare = pricePerShare;
        this.commissionRate = commissionRate;
        calculate();
    }

    private void calculate() {
        amountPaid = shares * pricePerShare;
        commission = amountPaid * commissionRate;
        totalAmount = amountPaid + commission;
    }

    public double getAmountPaid() {
        return amountPaid;
    }

    public double getCommission() {
        return commission;
    }

    public double getTotalAmount() {
        return totalAmount;
    }
}
