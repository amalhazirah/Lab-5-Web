// File: src/lab8/com/Register.java
package lab8.com;

public class Register {
    private int trainingType;
    private int student;
    private int participants;

    public int getTrainingType() {
        return trainingType;
    }

    public void setTrainingType(int trainingType) {
        this.trainingType = trainingType;
    }

    public int getStudent() {
        return student;
    }

    public void setStudent(int student) {
        this.student = student;
    }

    public int getParticipants() {
        return participants;
    }

    public void setParticipants(int participants) {
        this.participants = participants;
    }

    public double calculateTotalCost() {
        double costPerPax = 0.0;
        switch (trainingType) {
            case 1: costPerPax = 3000; break;
            case 2: costPerPax = 3000; break;
            case 3: costPerPax = 2800; break;
            case 4: costPerPax = 5500; break;
            case 5: costPerPax = 3200; break;
        }
        double totalCost = costPerPax * participants;
        if (student == 1) {
            totalCost *= 0.9; // 10% discount
        }
        return totalCost;
    }
}
